__version__ = "0.9.0"

import eventlet
eventlet.monkey_patch()